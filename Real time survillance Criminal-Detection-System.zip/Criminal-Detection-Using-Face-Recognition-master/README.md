# Criminal-Detection-Using-Face-Recognition
Criminal detection using face recognition based on supervised learning


//'Home.py' main file to run the project
